# RAF Messenger v29 — PostgreSQL ready

Эта версия подключена к нормальной базе PostgreSQL.

Добавлено:

- backend переписан на `pg`;
- поддержка `DATABASE_URL`;
- автоматическое создание таблиц;
- Supabase/PostgreSQL guide;
- аккаунты и чаты хранятся в Postgres.

## Быстро

1. Возьми PostgreSQL connection string.
2. В `.env` добавь:

```env
DATABASE_URL=postgresql://...
```

3. Запусти:

```bash
npm install
npm run dev:all
```

Читайте `POSTGRES_SUPABASE_GUIDE.md`.
