@echo off
chcp 65001 >nul
powershell -NoProfile -Command "(Get-Content .env) -replace '^FRONTEND_ORIGIN=.*','FRONTEND_ORIGIN=https://raf-messenger.onrender.com' -replace '^PUBLIC_APP_URL=.*','PUBLIC_APP_URL=https://raf-messenger.onrender.com' -replace '^PUBLIC_API_URL=.*','PUBLIC_API_URL=https://raf-messenger.onrender.com' -replace '^VITE_API_URL=.*','VITE_API_URL=https://raf-messenger.onrender.com' -replace '^VITE_WS_URL=.*','VITE_WS_URL=wss://raf-messenger.onrender.com/ws' -replace '^GOOGLE_REDIRECT_URI=.*','GOOGLE_REDIRECT_URI=https://raf-messenger.onrender.com/api/auth/google/callback' -replace '^COOKIE_SECURE=.*','COOKIE_SECURE=true' -replace '^TURN_URL=.*','TURN_URL=stun:stun.l.google.com:19302' | Set-Content .env"
echo RAF настроен под raf-messenger.onrender.com
echo Google OAuth redirect: https://raf-messenger.onrender.com/api/auth/google/callback
pause
