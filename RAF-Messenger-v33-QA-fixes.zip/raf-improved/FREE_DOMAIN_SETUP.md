# RAF Messenger — бесплатный домен на старте

На старт ставим бесплатный поддомен:

```txt
raf-messenger.onrender.com
```

Это не купленный домен, а бесплатный домен-хостинг от Render. Потом его можно заменить на свой `.ru/.com` через `SET_DOMAIN.bat`.

## Важно про нагрузку

Бесплатный тариф подходит для теста и первых друзей, но **не рассчитан стабильно на 500–1500 одновременных пользователей**. Для такой нагрузки лучше VPS 2–4 CPU / 4–8 GB RAM или платный контейнерный хостинг.

## Переключить проект на бесплатный домен

На Windows запусти:

```txt
SET_FREE_DOMAIN.bat
```

Он пропишет в `.env`:

```env
FRONTEND_ORIGIN=https://raf-messenger.onrender.com
PUBLIC_APP_URL=https://raf-messenger.onrender.com
PUBLIC_API_URL=https://raf-messenger.onrender.com
VITE_API_URL=https://raf-messenger.onrender.com
VITE_WS_URL=wss://raf-messenger.onrender.com/ws
GOOGLE_REDIRECT_URI=https://raf-messenger.onrender.com/api/auth/google/callback
COOKIE_SECURE=true
```

## Google OAuth

В Google Cloud Console добавь redirect URI:

```txt
https://raf-messenger.onrender.com/api/auth/google/callback
```

## Render deploy

1. Залей проект на GitHub.
2. В Render создай **Web Service**.
3. Build command:

```bash
npm install && npm run build:domain
```

4. Start command:

```bash
npm run server:prod
```

5. Environment variables:

```env
NODE_ENV=production
PORT=3001
DATABASE_URL=postgresql://...
JWT_SECRET=СЛОЖНЫЙ_СЕКРЕТ
FRONTEND_ORIGIN=https://raf-messenger.onrender.com
COOKIE_SECURE=true
GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
GOOGLE_REDIRECT_URI=https://raf-messenger.onrender.com/api/auth/google/callback
PUBLIC_APP_URL=https://raf-messenger.onrender.com
PUBLIC_API_URL=https://raf-messenger.onrender.com
VITE_API_URL=https://raf-messenger.onrender.com
VITE_WS_URL=wss://raf-messenger.onrender.com/ws
TURN_URL=stun:stun.l.google.com:19302
TURN_USERNAME=
TURN_PASSWORD=
UPLOAD_DIR=/var/lib/raf/uploads
```

## Проверка

```txt
https://raf-messenger.onrender.com
https://raf-messenger.onrender.com/api/health
```

## Если нужны 500–1500 человек

Минимально нормальный вариант:

- backend + frontend: VPS 2–4 vCPU, 4–8 GB RAM;
- database: отдельный managed Postgres/Supabase/Neon;
- файлы: S3-compatible storage, не локальная папка;
- WebSocket: держать один Node-процесс можно для старта, потом масштабировать через Redis pub/sub;
- звонки: нужен нормальный TURN-сервер, бесплатный STUN не спасает всех пользователей.
