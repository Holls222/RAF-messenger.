export type User={id:string;email:string;name:string;username:string;avatar?:string;bio?:string;onboardingCompleted?:boolean};
export type Chat={id:string;type?:string;title:string;username?:string;avatar:string;lastMessage:string;time:string;unread:number;online?:boolean;muted?:boolean;pinned?:boolean;archived?:boolean};
export type Reaction={emoji:string;userId:string};
export type Message={id:string;chatId:string;senderId?:string;author:"me"|"other";text:string;fileUrl?:string;fileName?:string;fileType?:string;createdAt:string;editedAt?:string;status?:"sending"|"sent";reaction?:string;reactions?:Reaction[];replyTo?:string;replyToId?:string;forwardedFrom?:string;forwardedFromId?:string;pinned?:boolean;deliveredAt?:string;readAt?:string};
export type Panel="chats"|"contacts"|"calls"|"saved"|"archive"|"settings";
export type ModalName="newChat"|"group"|"channel"|"call"|"callLink"|"callSettings"|"attach"|"emoji"|"profile"|"notify"|"news"|null;
export type DownloadTab="pc"|"android"|"web";
