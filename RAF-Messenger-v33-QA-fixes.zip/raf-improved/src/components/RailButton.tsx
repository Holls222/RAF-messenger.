import type {ReactNode} from "react";
export function RailButton({active,onClick,icon,label}:{active:boolean;onClick:()=>void;icon:ReactNode;label?:string}){return <button className={active?"railBtn active":"railBtn"} onClick={onClick} aria-label={label} title={label}>{icon}</button>}
