import {Sparkles} from "lucide-react";
export function EmptyState({title,description="Выберите действие в боковой панели."}:{title:string;description?:string}){return <div className="emptyState"><div className="emptyIcon"><Sparkles size={34}/></div><h2>{title}</h2><p>{description}</p></div>}
