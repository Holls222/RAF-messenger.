@echo off
chcp 65001 >nul
if not exist node_modules npm install
npm run electron:dev
pause
