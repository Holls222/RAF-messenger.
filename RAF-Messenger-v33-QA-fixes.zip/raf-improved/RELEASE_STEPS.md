# RAF release steps — что делать дальше

Это релиз-кандидат для показа друзьям.

## Локальное демо сегодня

```bash
npm install
npm run dev:all
```

Открыть:

```txt
http://localhost:5173
```

Проверять с двумя аккаунтами: обычный браузер + инкогнито/другой браузер.

## Чтобы дать друзьям не на твоём ПК

Нужны 4 вещи:

1. VPS
2. Домен
3. HTTPS
4. Google OAuth redirect под домен

## Настройка домена в проекте

На Windows запусти:

```txt
SET_DOMAIN.bat
```

Он поменяет `.env`:

```env
FRONTEND_ORIGIN=https://raf-messenger.onrender.com
PUBLIC_APP_URL=https://raf-messenger.onrender.com
PUBLIC_API_URL=https://raf-messenger.onrender.com
VITE_API_URL=https://raf-messenger.onrender.com
VITE_WS_URL=wss://raf-messenger.onrender.com/ws
GOOGLE_REDIRECT_URI=https://raf-messenger.onrender.com/api/auth/google/callback
COOKIE_SECURE=true
```

## Сборка web под домен

```bash
npm run build:domain
```

## Сборка EXE под домен

```bash
npm run electron:build:domain
```

EXE будет в:

```txt
release/
```

## TURN

Для звонков через интернет нужен TURN. Без него звонки могут работать у одних друзей и не работать у других.

Файл для сервера:

```txt
deploy/coturn.conf
```

Порты:

```txt
3478/tcp
3478/udp
49152-65535/udp
```

## Финальная проверка перед друзьями

- Google login работает
- username сохраняется
- Raf News появляется
- чат создаётся
- сообщение доходит
- файл/картинка отправляется
- уведомления включаются
- звонок открывается
- ссылка звонка копируется
- EXE запускается
