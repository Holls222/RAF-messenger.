# Нормальная база для RAF: PostgreSQL / Supabase

Ты прав: если база лежит только на твоём ПК, это не настоящий мессенджер.

В v29 backend переведён на PostgreSQL. Можно использовать Supabase Postgres.

## Что это даёт

- аккаунты не пропадают после перезапуска;
- база не зависит от твоего компьютера;
- можно потом подключить VPS/backend к этой же базе;
- SQLite больше не главный вариант.

## Что всё ещё нужно понимать

База — это только память. Чтобы сайт работал всегда, всё равно нужен backend, который где-то запущен.

Правильная схема:

```txt
Frontend + Backend на хостинге
↓
PostgreSQL/Supabase база
```

## Как сделать Supabase

1. Зайди на https://supabase.com
2. Создай аккаунт.
3. New project.
4. Сохрани пароль от базы.
5. Project Settings → Database → Connection string.
6. Возьми URI вида:

```txt
postgresql://postgres:password@db.xxxxx.supabase.co:5432/postgres
```

7. В `.env` добавь:

```env
DATABASE_URL=postgresql://postgres:password@db.xxxxx.supabase.co:5432/postgres
```

8. Запусти:

```bash
npm install
npm run dev:all
```

Первый запуск сам создаст таблицы.

## Если Supabase тоже попросит карту

Не вводи карту. Тогда ищем другой бесплатный Postgres:

- Neon
- Aiven trial
- локальный PostgreSQL для теста

## Локальный PostgreSQL

Если хочешь тестить без облака:

```env
DATABASE_URL=postgresql://postgres:password@localhost:5432/raf
```

Но друзьям через интернет всё равно понадобится hosting/backend.
