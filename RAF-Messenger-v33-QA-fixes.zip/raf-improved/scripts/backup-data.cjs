const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const dataDir = process.env.DATA_DIR || path.join(__dirname, '..', 'server', 'data');
const uploadsDir = process.env.UPLOAD_DIR || path.join(__dirname, '..', 'server', 'uploads');
const outDir = path.join(__dirname, '..', 'backups');
fs.mkdirSync(outDir, { recursive: true });
const stamp = new Date().toISOString().replace(/[:.]/g, '-');
const out = path.join(outDir, `raf-backup-${stamp}.json.gz`);
function readDirSafe(dir){ try { return fs.readdirSync(dir).map(name => ({ name, size: fs.statSync(path.join(dir, name)).size })); } catch { return []; } }
const backup = { createdAt: new Date().toISOString(), dataDir, uploadsDir, dataFiles: readDirSafe(dataDir), uploadFiles: readDirSafe(uploadsDir) };
fs.writeFileSync(out, zlib.gzipSync(JSON.stringify(backup, null, 2)));
console.log(`Backup manifest created: ${out}`);
console.log('Important: copy the actual raf.sqlite and uploads folder for full backup.');
