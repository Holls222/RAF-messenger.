@echo off
chcp 65001 >nul
set /p DOMAIN=Введите домен без https (например rafapp.ru): 
set APP=https://%DOMAIN%
set API=https://%DOMAIN%
set WS=wss://%DOMAIN%/ws
powershell -NoProfile -Command "(Get-Content .env) -replace '^FRONTEND_ORIGIN=.*','FRONTEND_ORIGIN=%APP%' -replace '^PUBLIC_APP_URL=.*','PUBLIC_APP_URL=%APP%' -replace '^PUBLIC_API_URL=.*','PUBLIC_API_URL=%API%' -replace '^VITE_API_URL=.*','VITE_API_URL=%API%' -replace '^VITE_WS_URL=.*','VITE_WS_URL=%WS%' -replace '^GOOGLE_REDIRECT_URI=.*','GOOGLE_REDIRECT_URI=%APP%/api/auth/google/callback' -replace '^COOKIE_SECURE=.*','COOKIE_SECURE=true' | Set-Content .env"
echo Готово. Проверь .env и Google OAuth redirect:
echo %APP%/api/auth/google/callback
pause
