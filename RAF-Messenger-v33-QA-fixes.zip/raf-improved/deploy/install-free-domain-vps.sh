#!/usr/bin/env bash
set -e
sudo apt update
sudo apt install -y nginx certbot python3-certbot-nginx curl ufw coturn
sudo mkdir -p /var/lib/raf/data /var/lib/raf/uploads
sudo chown -R $USER:$USER /var/lib/raf
npm install
npm run build:domain
sudo npm i -g pm2
pm2 start deploy/ecosystem.config.cjs
pm2 save
sudo cp deploy/nginx.free-domain.conf /etc/nginx/sites-available/raf
sudo ln -sf /etc/nginx/sites-available/raf /etc/nginx/sites-enabled/raf
sudo nginx -t
sudo systemctl reload nginx
sudo cp deploy/coturn.free-domain.conf /etc/turnserver.conf
sudo systemctl enable coturn
sudo systemctl restart coturn
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 3478/tcp
sudo ufw allow 3478/udp
sudo ufw allow 49152:65535/udp
printf "HTTPS для бесплатного поддомена Render уже выдаётся Render автоматически. Если используешь свой VPS и настоящий домен — запусти certbot под свой домен.\n"
