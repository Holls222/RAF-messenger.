module.exports = {
  apps: [
    {
      name: 'raf-backend',
      script: 'npm',
      args: 'run server:prod',
      cwd: process.cwd(),
      env: {
        NODE_ENV: 'production',
        PORT: '3001',
        DATA_DIR: '/var/lib/raf/data',
        UPLOAD_DIR: '/var/lib/raf/uploads'
      }
    },
    {
      name: 'raf-web',
      script: 'npm',
      args: 'run preview -- --host 127.0.0.1 --port 5173',
      cwd: process.cwd(),
      env: {
        NODE_ENV: 'production'
      }
    }
  ]
}
