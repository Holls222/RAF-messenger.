#!/usr/bin/env bash
set -e
sudo apt update
sudo apt install -y nginx certbot python3-certbot-nginx curl
npm install
sudo npm i -g pm2
pm2 start "npm run server" --name raf-backend
pm2 save
printf "Now copy deploy/nginx.raf.conf to /etc/nginx/sites-available/raf and edit domain.
"
