import http from "node:http";
import path from "node:path";
import crypto from "node:crypto";
import { promises as fs } from "node:fs";
import { fileURLToPath } from "node:url";
import { Pool } from "pg";
import { WebSocketServer } from "ws";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, "..");
const DIST_DIR = path.join(ROOT_DIR, "dist");
await loadEnvFile(path.join(ROOT_DIR, ".env"));

const PORT = Number(process.env.PORT || 3001);
const JWT_SECRET = process.env.JWT_SECRET || "raf-dev-secret-change-me";
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || "http://localhost:5173";
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || "";
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET || "";
const GOOGLE_REDIRECT_URI = process.env.GOOGLE_REDIRECT_URI || `${FRONTEND_ORIGIN}/api/auth/google/callback`;
const DATABASE_URL = process.env.DATABASE_URL || "";
const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || path.join(__dirname, "uploads"));
const TURN_URL = process.env.TURN_URL || "stun:stun.l.google.com:19302";
const TURN_USERNAME = process.env.TURN_USERNAME || "";
const TURN_PASSWORD = process.env.TURN_PASSWORD || "";

await fs.mkdir(UPLOAD_DIR, { recursive: true });
if (!DATABASE_URL) {
  console.warn("[RAF] DATABASE_URL is not set. Add PostgreSQL/Supabase DATABASE_URL to .env");
}
const pool = new Pool({
  connectionString: DATABASE_URL,
  ssl: DATABASE_URL.includes("localhost") || DATABASE_URL.includes("127.0.0.1") ? false : { rejectUnauthorized: false },
});
await initDb();

async function loadEnvFile(filePath) {
  try {
    const text = await fs.readFile(filePath, "utf8");
    for (const raw of text.split(/\r?\n/)) {
      const line = raw.trim();
      if (!line || line.startsWith("#")) continue;
      const eq = line.indexOf("=");
      if (eq < 0) continue;
      const key = line.slice(0, eq).trim();
      let value = line.slice(eq + 1).trim();
      if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
      if (!process.env[key]) process.env[key] = value;
    }
  } catch {}
}
async function q(text, params = []) { return pool.query(text, params); }
async function one(text, params = []) { const r = await q(text, params); return r.rows[0] || null; }
async function all(text, params = []) { const r = await q(text, params); return r.rows; }
async function initDb() {
  if (!DATABASE_URL) return;
  await q(`CREATE TABLE IF NOT EXISTS users(
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    username TEXT UNIQUE,
    avatar TEXT,
    bio TEXT DEFAULT '',
    google_id TEXT UNIQUE,
    onboarding_completed BOOLEAN DEFAULT FALSE,
    profile_version INTEGER DEFAULT 0,
    last_login_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL
  )`);
  await q(`ALTER TABLE users ADD COLUMN IF NOT EXISTS profile_version INTEGER DEFAULT 0`);
  await q(`ALTER TABLE users ADD COLUMN IF NOT EXISTS last_login_at TIMESTAMPTZ`);
  await q(`CREATE TABLE IF NOT EXISTS chats(
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    title TEXT,
    description TEXT DEFAULT '',
    owner_id TEXT,
    created_at TIMESTAMPTZ NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL
  )`);
  await q(`CREATE TABLE IF NOT EXISTS chat_members(
    chat_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    role TEXT DEFAULT 'member',
    PRIMARY KEY(chat_id,user_id)
  )`);
  await q(`CREATE TABLE IF NOT EXISTS messages(
    id TEXT PRIMARY KEY,
    chat_id TEXT NOT NULL,
    sender_id TEXT NOT NULL,
    text TEXT DEFAULT '',
    file_url TEXT DEFAULT '',
    file_name TEXT DEFAULT '',
    file_type TEXT DEFAULT '',
    created_at TIMESTAMPTZ NOT NULL,
    edited_at TIMESTAMPTZ
  )`);
  await q(`CREATE TABLE IF NOT EXISTS friends(
    user_id TEXT NOT NULL,
    friend_id TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY(user_id,friend_id)
  )`);
  await q(`ALTER TABLE messages ADD COLUMN IF NOT EXISTS reply_to_id TEXT`);
  await q(`ALTER TABLE messages ADD COLUMN IF NOT EXISTS forwarded_from_id TEXT`);
  await q(`ALTER TABLE messages ADD COLUMN IF NOT EXISTS is_pinned BOOLEAN DEFAULT FALSE`);
  await q(`ALTER TABLE messages ADD COLUMN IF NOT EXISTS delivered_at TIMESTAMPTZ`);
  await q(`ALTER TABLE messages ADD COLUMN IF NOT EXISTS read_at TIMESTAMPTZ`);
  await q(`CREATE TABLE IF NOT EXISTS message_reactions(
    message_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    emoji TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY(message_id,user_id)
  )`);
  await q(`CREATE TABLE IF NOT EXISTS chat_reads(
    chat_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    last_read_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY(chat_id,user_id)
  )`);
  await q(`CREATE TABLE IF NOT EXISTS schema_migrations(
    version INTEGER PRIMARY KEY,
    applied_at TIMESTAMPTZ NOT NULL
  )`);
  await q(`INSERT INTO schema_migrations(version,applied_at) VALUES(31,NOW()) ON CONFLICT DO NOTHING`);
  await q(`CREATE INDEX IF NOT EXISTS idx_members_user ON chat_members(user_id)`);
  await q(`CREATE INDEX IF NOT EXISTS idx_messages_chat ON messages(chat_id,created_at)`);
  const rafNews=await ensureRafNewsChannel();
  await publishRafUpdate(rafNews.id,"Обновление 3.3\n\n• Исправлено отображение настроек\n• Добавлен просмотр аватаров\n• Действия сообщения открываются по нажатию\n• Голосовые больше нельзя редактировать\n• Исправлена работа в узком окне");
}
function json(res, status, data, extra = {}) {
  res.writeHead(status, {"Content-Type":"application/json; charset=utf-8","Access-Control-Allow-Origin":FRONTEND_ORIGIN,"Access-Control-Allow-Methods":"GET,POST,PATCH,DELETE,OPTIONS","Access-Control-Allow-Headers":"Content-Type, Authorization","Access-Control-Allow-Credentials":"true",...extra});
  res.end(JSON.stringify(data));
}
function readBody(req) { return new Promise((resolve,reject)=>{ let body=""; req.on("data",c=>{body+=c;if(body.length>15_000_000){reject(new Error("Body too large"));req.destroy();}}); req.on("end",()=>{try{resolve(body?JSON.parse(body):{})}catch{reject(new Error("Invalid JSON"))}}); }); }
function isPlaceholder(v){ return !v || String(v).includes("PUT_") || String(v).includes("change-this-secret"); }
function b64(o){ return Buffer.from(JSON.stringify(o)).toString("base64url"); }
function signToken(payload){ const h=b64({alg:"HS256",typ:"JWT"}); const b=b64(payload); const s=crypto.createHmac("sha256",JWT_SECRET).update(`${h}.${b}`).digest("base64url"); return `${h}.${b}.${s}`; }
function verifyToken(t){ if(!t)return null; const p=t.split("."); if(p.length!==3)return null; const [h,b,s]=p; const e=crypto.createHmac("sha256",JWT_SECRET).update(`${h}.${b}`).digest("base64url"); if(!crypto.timingSafeEqual(Buffer.from(s),Buffer.from(e)))return null; const payload=JSON.parse(Buffer.from(b,"base64url").toString("utf8")); if(payload.exp&&Date.now()>payload.exp)return null; return payload; }
function cookies(req){ const out={}; for(const part of String(req.headers.cookie||"").split(";")){ const [k,...v]=part.trim().split("="); if(k)out[k]=decodeURIComponent(v.join("=")); } return out; }
function setSession(res,token){ res.setHeader("Set-Cookie",`raf_session=${encodeURIComponent(token)}; HttpOnly; Path=/; Max-Age=${60*60*24*30}; SameSite=Lax${process.env.COOKIE_SECURE==="true"?"; Secure":""}`); }
function clearSession(res){ res.setHeader("Set-Cookie","raf_session=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax"); }
function authPayload(req){ const auth=req.headers.authorization||""; return verifyToken((auth.startsWith("Bearer ")?auth.slice(7):"")||cookies(req).raf_session||""); }
async function requireUser(req,res){ const p=authPayload(req); if(!p){json(res,401,{error:"Не авторизован"});return null;} const u=await one("SELECT * FROM users WHERE id=$1",[p.sub]); if(!u){json(res,401,{error:"Пользователь не найден"});return null;} return u; }
function publicUser(u){ return u?{id:u.id,email:u.email,name:u.name,username:u.username,avatar:u.avatar,bio:u.bio||"",onboardingCompleted:!!u.onboarding_completed||Number(u.profile_version||0)>=1}:null; }
function googleConfigured(){ return GOOGLE_CLIENT_ID&&GOOGLE_CLIENT_SECRET&&!isPlaceholder(GOOGLE_CLIENT_ID)&&!isPlaceholder(GOOGLE_CLIENT_SECRET); }
async function makeUsername(email){ let base=email.split("@")[0].toLowerCase().replace(/[^a-z0-9_]/g,"_").slice(0,18)||"user"; let name=base,i=1; while(await one("SELECT id FROM users WHERE username=$1",[name])) name=`${base}${i++}`; return name; }
async function googleStart(req,res){ if(!googleConfigured())return json(res,500,{error:"Google OAuth не настроен в .env"}); const state=crypto.randomBytes(18).toString("hex"); res.writeHead(302,{"Set-Cookie":`raf_oauth_state=${state}; HttpOnly; Path=/; Max-Age=600; SameSite=Lax`,Location:"https://accounts.google.com/o/oauth2/v2/auth?"+new URLSearchParams({client_id:GOOGLE_CLIENT_ID,redirect_uri:GOOGLE_REDIRECT_URI,response_type:"code",scope:"openid email profile",state,prompt:"select_account"}).toString()}); res.end(); }
async function googleCallback(req,res,url){ try{ const code=url.searchParams.get("code")||"",state=url.searchParams.get("state")||""; if(!code||state!==cookies(req).raf_oauth_state)throw new Error("Google вход не подтверждён"); const tokenRes=await fetch("https://oauth2.googleapis.com/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({code,client_id:GOOGLE_CLIENT_ID,client_secret:GOOGLE_CLIENT_SECRET,redirect_uri:GOOGLE_REDIRECT_URI,grant_type:"authorization_code"})}); const tokens=await tokenRes.json(); if(!tokenRes.ok)throw new Error(tokens.error_description||"Google token error"); const infoRes=await fetch("https://oauth2.googleapis.com/tokeninfo?id_token="+encodeURIComponent(tokens.id_token)); const p=await infoRes.json(); if(!infoRes.ok||p.aud!==GOOGLE_CLIENT_ID)throw new Error("Google profile error"); const email=String(p.email).toLowerCase(),googleId=String(p.sub),name=String(p.name||email.split("@")[0]),avatar=p.picture||"",now=new Date().toISOString(); let u=await one("SELECT * FROM users WHERE google_id=$1 OR email=$2",[googleId,email]); if(u){ await q("UPDATE users SET google_id=$1,email=$2,last_login_at=$3,updated_at=$3 WHERE id=$4",[googleId,email,now,u.id]); u=await one("SELECT * FROM users WHERE id=$1",[u.id]); } else { const id=crypto.randomUUID(),username=await makeUsername(email); await q("INSERT INTO users(id,email,name,username,avatar,google_id,onboarding_completed,profile_version,last_login_at,created_at,updated_at) VALUES($1,$2,$3,$4,$5,$6,false,0,$7,$7,$7)",[id,email,name,username,avatar,googleId,now]); u=await one("SELECT * FROM users WHERE id=$1",[id]); } await ensureRafNewsMembership(u.id); const jwt=signToken({sub:u.id,email:u.email,exp:Date.now()+1000*60*60*24*30}); res.writeHead(302,{"Set-Cookie":[`raf_session=${encodeURIComponent(jwt)}; HttpOnly; Path=/; Max-Age=${60*60*24*30}; SameSite=Lax${process.env.COOKIE_SECURE==="true"?"; Secure":""}`,'raf_oauth_state=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax'],Location:`${FRONTEND_ORIGIN}?login=google`}); res.end(); }catch(e){ res.writeHead(302,{Location:`${FRONTEND_ORIGIN}?authError=${encodeURIComponent(e instanceof Error?e.message:"Google error")}`}); res.end(); } }
async function me(req,res){ const u=await requireUser(req,res); if(u)json(res,200,{ok:true,user:publicUser(u)}); }
async function logout(req,res){ clearSession(res); json(res,200,{ok:true}); }
async function profile(req,res){ const u=await requireUser(req,res); if(!u)return; const b=await readBody(req); const name=String(b.name||"").trim().slice(0,50); const username=String(b.username||"").trim().replace(/^@/,"").toLowerCase().replace(/[^a-z0-9_]/g,"").slice(0,24); const bio=String(b.bio||"").trim().slice(0,140); const avatar=String(b.avatar||u.avatar||""); const done=b.onboardingCompleted===true?true:!!u.onboarding_completed; const profileVersion=done?1:Number(u.profile_version||0); if(name.length<2)return json(res,400,{error:"Введите имя"}); if(username.length<3)return json(res,400,{error:"Username минимум 3 символа"}); if(await one("SELECT id FROM users WHERE username=$1 AND id<>$2",[username,u.id]))return json(res,409,{error:"Username занят"}); await q("UPDATE users SET name=$1,username=$2,bio=$3,avatar=$4,onboarding_completed=$5,profile_version=$6,updated_at=$7 WHERE id=$8",[name,username,bio,avatar,done,profileVersion,new Date().toISOString(),u.id]); json(res,200,{ok:true,user:publicUser(await one("SELECT * FROM users WHERE id=$1",[u.id]))}); }
async function ensureRafBot(){ let bot=await one("SELECT * FROM users WHERE id='raf_bot'"); if(!bot){ const now=new Date().toISOString(); await q("INSERT INTO users(id,email,name,username,avatar,bio,google_id,onboarding_completed,created_at,updated_at) VALUES('raf_bot','bot@raf.local','RAF Bot','raf_bot','R','Системный бот RAF','raf_bot',true,$1,$1)",[now]); bot=await one("SELECT * FROM users WHERE id='raf_bot'"); } return bot; }
async function ensureRafNewsChannel(){ const bot=await ensureRafBot(); const now=new Date().toISOString(); let ch=await one("SELECT * FROM chats WHERE type='channel' AND title='Raf News' LIMIT 1"); if(!ch){ const id=crypto.randomUUID(); await q("INSERT INTO chats(id,type,title,description,owner_id,created_at,updated_at) VALUES($1,'channel','Raf News','Новости RAF',$2,$3,$3)",[id,bot.id,now]); await q("INSERT INTO chat_members(chat_id,user_id,role) VALUES($1,$2,'owner') ON CONFLICT DO NOTHING",[id,bot.id]); const mid=crypto.randomUUID(); await q("INSERT INTO messages(id,chat_id,sender_id,text,created_at) VALUES($1,$2,$3,$4,$5)",[mid,id,bot.id,"Добро пожаловать в Raf News. Здесь будут новости RAF.",now]); ch=await one("SELECT * FROM chats WHERE id=$1",[id]); } return ch; }
async function ensureRafNewsMembership(userId){ const ch=await ensureRafNewsChannel(); await q("INSERT INTO chat_members(chat_id,user_id,role) VALUES($1,$2,'member') ON CONFLICT DO NOTHING",[ch.id,userId]); return ch; }
async function publishRafUpdate(chatId,text){ const exists=await one("SELECT id FROM messages WHERE chat_id=$1 AND sender_id='raf_bot' AND text=$2 LIMIT 1",[chatId,text]); if(exists)return; const id=crypto.randomUUID(),now=new Date().toISOString(); await q("INSERT INTO messages(id,chat_id,sender_id,text,delivered_at,created_at) VALUES($1,$2,'raf_bot',$3,$4,$4)",[id,chatId,text,now]); await q("UPDATE chats SET updated_at=$1 WHERE id=$2",[now,chatId]); }
async function joinRafChannel(req,res){ const u=await requireUser(req,res); if(!u)return; const ch=await ensureRafNewsChannel(); await q("INSERT INTO chat_members(chat_id,user_id,role) VALUES($1,$2,'member') ON CONFLICT DO NOTHING",[ch.id,u.id]); json(res,200,{ok:true,chat:await chatFor(ch,u)}); }
async function searchUser(req,res,url){ const u=await requireUser(req,res); if(!u)return; const query=String(url.searchParams.get("q")||"").trim().replace(/^@/,"").toLowerCase(); const found=await one("SELECT * FROM users WHERE lower(username)=lower($1)",[query]); if(!found)return json(res,404,{error:"Пользователь не найден"}); if(found.id===u.id)return json(res,400,{error:"Это ваш аккаунт"}); json(res,200,{ok:true,user:publicUser(found)}); }
async function addFriend(req,res){ const u=await requireUser(req,res); if(!u)return; const b=await readBody(req); const username=String(b.username||"").trim().replace(/^@/,"").toLowerCase(); const f=await one("SELECT * FROM users WHERE lower(username)=lower($1)",[username]); if(!f)return json(res,404,{error:"Пользователь не найден"}); if(f.id===u.id)return json(res,400,{error:"Нельзя добавить себя"}); const now=new Date().toISOString(); await q("INSERT INTO friends(user_id,friend_id,created_at) VALUES($1,$2,$3) ON CONFLICT DO NOTHING",[u.id,f.id,now]); await q("INSERT INTO friends(user_id,friend_id,created_at) VALUES($1,$2,$3) ON CONFLICT DO NOTHING",[f.id,u.id,now]); json(res,200,{ok:true,friend:publicUser(f)}); }
async function listFriends(req,res){ const u=await requireUser(req,res); if(!u)return; const rows=await all("SELECT users.* FROM users JOIN friends ON friends.friend_id=users.id WHERE friends.user_id=$1 ORDER BY users.name",[u.id]); json(res,200,{ok:true,friends:rows.map(publicUser)}); }
async function chatFor(c,u){ let title=c.title,username="",avatar=(c.title||"?").slice(0,1).toUpperCase(); if(c.type==='private'){ const other=await one("SELECT users.* FROM users JOIN chat_members cm ON cm.user_id=users.id WHERE cm.chat_id=$1 AND users.id<>$2 LIMIT 1",[c.id,u.id]); title=other?.name||"Пользователь"; username=other?.username||""; avatar=other?.avatar||(other?.name||other?.username||"?").slice(0,1).toUpperCase(); } const last=await one("SELECT * FROM messages WHERE chat_id=$1 ORDER BY created_at DESC LIMIT 1",[c.id]); return {id:c.id,type:c.type,title:title||"Чат",username,avatar,lastMessage:last?.text||last?.file_name||"Чат создан",time:last?new Date(last.created_at).toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"}):"",unread:0}; }
async function listChats(req,res){ const u=await requireUser(req,res); if(!u)return; await ensureRafNewsMembership(u.id); const rows=await all("SELECT chats.* FROM chats JOIN chat_members cm ON cm.chat_id=chats.id WHERE cm.user_id=$1 ORDER BY chats.updated_at DESC",[u.id]); const chats=[]; for(const c of rows)chats.push(await chatFor(c,u)); json(res,200,{ok:true,chats,online:[...onlineUsers.keys()]}); }
async function addMembers(chatId,usernames){ for(const raw of usernames){ const username=String(raw||"").trim().replace(/^@/,"").toLowerCase(); const u=await one("SELECT * FROM users WHERE lower(username)=lower($1)",[username]); if(u)await q("INSERT INTO chat_members(chat_id,user_id) VALUES($1,$2) ON CONFLICT DO NOTHING",[chatId,u.id]); } }
async function createChat(req,res,type){ const u=await requireUser(req,res); if(!u)return; const b=await readBody(req); const now=new Date().toISOString(); if(type==='private'){ const username=String(b.username||"").trim().replace(/^@/,"").toLowerCase(); const other=await one("SELECT * FROM users WHERE lower(username)=lower($1)",[username]); if(!other)return json(res,404,{error:"Пользователь не найден"}); if(other.id===u.id)return json(res,400,{error:"Нельзя создать чат с собой"}); let chat=await one("SELECT c.* FROM chats c JOIN chat_members a ON a.chat_id=c.id JOIN chat_members b ON b.chat_id=c.id WHERE c.type='private' AND a.user_id=$1 AND b.user_id=$2 LIMIT 1",[u.id,other.id]); if(!chat){ const id=crypto.randomUUID(); await q("INSERT INTO chats(id,type,title,owner_id,created_at,updated_at) VALUES($1,'private','',$2,$3,$3)",[id,u.id,now]); await q("INSERT INTO chat_members(chat_id,user_id) VALUES($1,$2)",[id,u.id]); await q("INSERT INTO chat_members(chat_id,user_id) VALUES($1,$2)",[id,other.id]); chat=await one("SELECT * FROM chats WHERE id=$1",[id]); } return json(res,201,{ok:true,chat:await chatFor(chat,u)}); } const title=String(b.title||"").trim().slice(0,60); if(title.length<2)return json(res,400,{error:"Введите название"}); const id=crypto.randomUUID(); await q("INSERT INTO chats(id,type,title,description,owner_id,created_at,updated_at) VALUES($1,$2,$3,$4,$5,$6,$6)",[id,type,title,String(b.description||""),u.id,now]); await q("INSERT INTO chat_members(chat_id,user_id,role) VALUES($1,$2,'owner')",[id,u.id]); await addMembers(id,b.members||[]); json(res,201,{ok:true,chat:await chatFor(await one("SELECT * FROM chats WHERE id=$1",[id]),u)}); }
async function getMessages(req,res,chatId){
  const u=await requireUser(req,res); if(!u)return;
  if(!await one("SELECT * FROM chat_members WHERE chat_id=$1 AND user_id=$2",[chatId,u.id]))return json(res,404,{error:"Чат не найден"});
  const rows=await all(`SELECT m.*, reply.text AS reply_text, original.text AS forwarded_text,
    COALESCE((SELECT json_agg(json_build_object('emoji',r.emoji,'userId',r.user_id)) FROM message_reactions r WHERE r.message_id=m.id),'[]'::json) AS reactions
    FROM messages m
    LEFT JOIN messages reply ON reply.id=m.reply_to_id
    LEFT JOIN messages original ON original.id=m.forwarded_from_id
    WHERE m.chat_id=$1 ORDER BY m.created_at ASC`,[chatId]);
  json(res,200,{ok:true,messages:rows.map(m=>({id:m.id,chatId:m.chat_id,senderId:m.sender_id,text:m.text,fileUrl:m.file_url,fileName:m.file_name,fileType:m.file_type,createdAt:m.created_at,editedAt:m.edited_at,author:m.sender_id===u.id?'me':'other',replyTo:m.reply_text||'',replyToId:m.reply_to_id||'',forwardedFrom:m.forwarded_text||'',forwardedFromId:m.forwarded_from_id||'',pinned:!!m.is_pinned,reactions:m.reactions||[],deliveredAt:m.delivered_at,readAt:m.read_at}))});
}
function broadcastChat(chatId,msg){ q("SELECT user_id FROM chat_members WHERE chat_id=$1",[chatId]).then(r=>{ for(const row of r.rows){ for(const ws of sockets.get(row.user_id)||[])send(ws,msg); } }); }
async function sendMsg(req,res,chatId){
  const u=await requireUser(req,res); if(!u)return;
  if(!await one("SELECT * FROM chat_members WHERE chat_id=$1 AND user_id=$2",[chatId,u.id]))return json(res,404,{error:"Чат не найден"});
  const b=await readBody(req); const text=String(b.text||"").trim(); const file=b.file||null;
  if(!text&&!file)return json(res,400,{error:"Сообщение пустое"});
  const id=crypto.randomUUID(),now=new Date().toISOString(); let fileUrl='',fileName='',fileType='';
  if(file?.data&&file?.name){ const ext=path.extname(file.name).replace(/[^.a-z0-9]/gi,"").slice(0,8); fileName=String(file.name).slice(0,120); fileType=String(file.type||"file"); const name=`${id}${ext||".bin"}`; const base64=String(file.data).split(",").pop(); await fs.writeFile(path.join(UPLOAD_DIR,name),Buffer.from(base64,"base64")); fileUrl=`/uploads/${name}`; }
  const replyToId=String(b.replyToId||"")||null,forwardedFromId=String(b.forwardedFromId||"")||null;
  await q("INSERT INTO messages(id,chat_id,sender_id,text,file_url,file_name,file_type,reply_to_id,forwarded_from_id,delivered_at,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$10)",[id,chatId,u.id,text,fileUrl,fileName,fileType,replyToId,forwardedFromId,now]);
  await q("UPDATE chats SET updated_at=$1 WHERE id=$2",[now,chatId]);
  const message={id,chatId,senderId:u.id,text,fileUrl,fileName,fileType,replyToId,forwardedFromId,createdAt:now,deliveredAt:now,author:'other'};
  broadcastChat(chatId,{type:'message',chatId,message}); json(res,201,{ok:true,message:{...message,author:'me'}});
}
async function editMsg(req,res,id){ const u=await requireUser(req,res); if(!u)return; const b=await readBody(req); const text=String(b.text||"").trim(); const m=await one("SELECT * FROM messages WHERE id=$1",[id]); if(!m||m.sender_id!==u.id)return json(res,404,{error:"Сообщение не найдено"}); await q("UPDATE messages SET text=$1,edited_at=$2 WHERE id=$3",[text,new Date().toISOString(),id]); broadcastChat(m.chat_id,{type:'message_edit',chatId:m.chat_id,messageId:id,text}); json(res,200,{ok:true}); }
async function deleteMsg(req,res,id){ const u=await requireUser(req,res); if(!u)return; const m=await one("SELECT * FROM messages WHERE id=$1",[id]); if(!m||m.sender_id!==u.id)return json(res,404,{error:"Сообщение не найдено"}); await q("DELETE FROM messages WHERE id=$1",[id]); broadcastChat(m.chat_id,{type:'message_delete',chatId:m.chat_id,messageId:id}); json(res,200,{ok:true}); }
async function reactMsg(req,res,id){ const u=await requireUser(req,res);if(!u)return;const b=await readBody(req);const emoji=String(b.emoji||'').slice(0,12);const m=await one("SELECT * FROM messages WHERE id=$1",[id]);if(!m)return json(res,404,{error:'Сообщение не найдено'});if(!emoji)await q("DELETE FROM message_reactions WHERE message_id=$1 AND user_id=$2",[id,u.id]);else await q("INSERT INTO message_reactions(message_id,user_id,emoji,created_at) VALUES($1,$2,$3,$4) ON CONFLICT(message_id,user_id) DO UPDATE SET emoji=EXCLUDED.emoji,created_at=EXCLUDED.created_at",[id,u.id,emoji,new Date().toISOString()]);broadcastChat(m.chat_id,{type:'reaction',chatId:m.chat_id,messageId:id,emoji,userId:u.id});json(res,200,{ok:true}); }
async function pinMsg(req,res,id){ const u=await requireUser(req,res);if(!u)return;const m=await one("SELECT * FROM messages WHERE id=$1",[id]);if(!m)return json(res,404,{error:'Сообщение не найдено'});const pinned=!m.is_pinned;await q("UPDATE messages SET is_pinned=$1 WHERE id=$2",[pinned,id]);broadcastChat(m.chat_id,{type:'message_pin',chatId:m.chat_id,messageId:id,pinned});json(res,200,{ok:true,pinned}); }
async function forwardMsg(req,res,id){ const u=await requireUser(req,res);if(!u)return;const b=await readBody(req);const target=String(b.chatId||'');const src=await one("SELECT * FROM messages WHERE id=$1",[id]);if(!src||!await one("SELECT 1 FROM chat_members WHERE chat_id=$1 AND user_id=$2",[target,u.id]))return json(res,404,{error:'Сообщение или чат не найдены'});const mid=crypto.randomUUID(),now=new Date().toISOString();await q("INSERT INTO messages(id,chat_id,sender_id,text,file_url,file_name,file_type,forwarded_from_id,delivered_at,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$9)",[mid,target,u.id,src.text,src.file_url,src.file_name,src.file_type,src.id,now]);await q("UPDATE chats SET updated_at=$1 WHERE id=$2",[now,target]);broadcastChat(target,{type:'message',chatId:target,message:{id:mid,chatId:target,senderId:u.id,text:src.text,fileUrl:src.file_url,fileName:src.file_name,fileType:src.file_type,forwardedFromId:src.id,createdAt:now,deliveredAt:now,author:'other'}});json(res,201,{ok:true}); }
async function markRead(req,res,chatId){const u=await requireUser(req,res);if(!u)return;const now=new Date().toISOString();await q("UPDATE messages SET read_at=$1 WHERE chat_id=$2 AND sender_id<>$3 AND read_at IS NULL",[now,chatId,u.id]);await q("INSERT INTO chat_reads(chat_id,user_id,last_read_at) VALUES($1,$2,$3) ON CONFLICT(chat_id,user_id) DO UPDATE SET last_read_at=EXCLUDED.last_read_at",[chatId,u.id,now]);broadcastChat(chatId,{type:'message_read',chatId,userId:u.id,readAt:now});json(res,200,{ok:true,readAt:now});}
async function searchAll(req,res,url){const u=await requireUser(req,res);if(!u)return;const term=String(url.searchParams.get('q')||'').trim();const chatId=String(url.searchParams.get('chatId')||'');if(term.length<2)return json(res,200,{ok:true,messages:[]});const like='%'+term+'%';const params=chatId?[u.id,like,chatId]:[u.id,like];const extra=chatId?' AND m.chat_id=$3':'';const rows=await all(`SELECT m.* FROM messages m JOIN chat_members cm ON cm.chat_id=m.chat_id WHERE cm.user_id=$1 AND (m.text ILIKE $2 OR m.file_name ILIKE $2)${extra} ORDER BY m.created_at DESC LIMIT 100`,params);json(res,200,{ok:true,messages:rows.map(m=>({id:m.id,chatId:m.chat_id,senderId:m.sender_id,text:m.text,fileUrl:m.file_url,fileName:m.file_name,fileType:m.file_type,createdAt:m.created_at,author:m.sender_id===u.id?'me':'other',pinned:!!m.is_pinned,deliveredAt:m.delivered_at,readAt:m.read_at}))});}
async function serveUpload(req,res,p){ const name=path.basename(p.replace('/uploads/','')); try{ const data=await fs.readFile(path.join(UPLOAD_DIR,name)); res.writeHead(200,{"Access-Control-Allow-Origin":FRONTEND_ORIGIN}); res.end(data); }catch{res.writeHead(404);res.end();} }
async function serveStatic(req,res,p){
  try{
    let filePath=p==='/'?path.join(DIST_DIR,'index.html'):path.join(DIST_DIR,p.replace(/^\//,''));
    if(!filePath.startsWith(DIST_DIR))throw new Error('bad');
    try{await fs.access(filePath)}catch{filePath=path.join(DIST_DIR,'index.html')}
    const data=await fs.readFile(filePath);
    const ext=path.extname(filePath).toLowerCase();
    const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.ico':'image/x-icon'};
    res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream'});
    res.end(data);
  }catch{
    if(!res.headersSent){res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'});res.end('Not found')}
    else if(!res.writableEnded)res.end();
  }
}
const server=http.createServer(async(req,res)=>{ try{ if(req.method==='OPTIONS')return json(res,200,{ok:true}); const url=new URL(req.url||'/', 'http://'+req.headers.host); const p=url.pathname; if(p.startsWith('/uploads/'))return serveUpload(req,res,p); if(req.method==='GET'&&p==='/api/call/config')return json(res,200,{ok:true,iceServers:[{urls:'stun:stun.l.google.com:19302'},{urls:TURN_URL,username:TURN_USERNAME,credential:TURN_PASSWORD}]}); if(req.method==='GET'&&p==='/api/health')return json(res,200,{ok:true,db:'postgres',ws:true}); if(req.method==='GET'&&p==='/api/auth/google/start')return googleStart(req,res); if(req.method==='GET'&&p==='/api/auth/google/callback')return googleCallback(req,res,url); if(req.method==='POST'&&p==='/api/auth/logout')return logout(req,res); if(req.method==='GET'&&p==='/api/me')return me(req,res); if(req.method==='POST'&&p==='/api/me/profile')return profile(req,res); if(req.method==='POST'&&p==='/api/raf-channel/join')return joinRafChannel(req,res); if(req.method==='GET'&&p==='/api/users/search')return searchUser(req,res,url); if(req.method==='GET'&&p==='/api/friends')return listFriends(req,res); if(req.method==='POST'&&p==='/api/friends')return addFriend(req,res); if(req.method==='GET'&&p==='/api/chats')return listChats(req,res); if(req.method==='POST'&&p==='/api/chats/private')return createChat(req,res,'private'); if(req.method==='POST'&&p==='/api/chats/group')return createChat(req,res,'group'); if(req.method==='POST'&&p==='/api/chats/channel')return createChat(req,res,'channel'); let mm=p.match(/^\/api\/chats\/([^/]+)\/messages$/); if(mm&&req.method==='GET')return getMessages(req,res,mm[1]); if(mm&&req.method==='POST')return sendMsg(req,res,mm[1]); let em=p.match(/^\/api\/messages\/([^/]+)$/); if(em&&req.method==='PATCH')return editMsg(req,res,em[1]); if(em&&req.method==='DELETE')return deleteMsg(req,res,em[1]); if(em&&req.method==='POST'&&url.searchParams.get('action')==='reaction')return reactMsg(req,res,em[1]); if(em&&req.method==='POST'&&url.searchParams.get('action')==='pin')return pinMsg(req,res,em[1]); if(em&&req.method==='POST'&&url.searchParams.get('action')==='forward')return forwardMsg(req,res,em[1]); let read=p.match(/^\/api\/chats\/([^/]+)\/read$/); if(read&&req.method==='POST')return markRead(req,res,read[1]); if(req.method==='GET'&&p==='/api/search')return searchAll(req,res,url); if(req.method==='GET')return serveStatic(req,res,p); json(res,404,{error:'Not found'}); }catch(e){ console.error(e); json(res,500,{error:e instanceof Error?e.message:'Ошибка сервера'}); } });
const wss=new WebSocketServer({server,path:'/ws'}); const sockets=new Map(); const onlineUsers=new Map(); function send(ws,obj){try{ws.send(JSON.stringify(obj))}catch{}}
wss.on('connection',(ws,req)=>{ const p=authPayload(req); if(!p){ws.close();return;} if(!sockets.has(p.sub))sockets.set(p.sub,new Set()); sockets.get(p.sub).add(ws); onlineUsers.set(p.sub,Date.now()); broadcastOnline(); ws.on('message',raw=>{try{const msg=JSON.parse(raw); if(msg.type==='typing'&&msg.chatId)broadcastChat(msg.chatId,{type:'typing',chatId:msg.chatId,userId:p.sub,isTyping:!!msg.isTyping}); if(msg.type==='call_signal'&&msg.callId)broadcastCall(msg.callId,{type:'call_signal',callId:msg.callId,userId:p.sub,signal:msg.signal}); if(msg.type==='call_join'&&msg.callId){ws.callId=msg.callId; broadcastCall(msg.callId,{type:'call_user_joined',callId:msg.callId,user:{id:p.sub}});} }catch{}}); ws.on('close',()=>{ if(ws.callId)broadcastCall(ws.callId,{type:'call_user_left',callId:ws.callId,user:{id:p.sub}}); sockets.get(p.sub)?.delete(ws); if(!sockets.get(p.sub)?.size){sockets.delete(p.sub);onlineUsers.delete(p.sub);} broadcastOnline(); }); });
function broadcastOnline(){ const msg={type:'online',users:[...onlineUsers.keys()]}; for(const set of sockets.values())for(const ws of set)send(ws,msg); }
function broadcastCall(callId,msg){ for(const set of sockets.values())for(const ws of set)if(ws.callId===callId)send(ws,msg); }
server.listen(PORT,()=>console.log(`RAF backend: http://localhost:${PORT}`));
