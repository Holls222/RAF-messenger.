const { contextBridge } = require('electron');contextBridge.exposeInMainWorld('rafDesktop',{isDesktop:true});
