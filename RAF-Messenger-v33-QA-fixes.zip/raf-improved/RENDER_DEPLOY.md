# Render deploy для RAF Messenger

Рекомендованный бесплатный поддомен:

```txt
https://raf-messenger.onrender.com
```

## Команды Render

Build command:

```bash
npm install && npm run build:domain
```

Start command:

```bash
npm run server:prod
```

Health check path:

```txt
/api/health
```

## Env variables

Скопируй `.env.production.example` и заполни секреты в панели Render.

Обязательно:

```env
DATABASE_URL=postgresql://...
JWT_SECRET=long-random-secret
GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
```

## Нагрузка

Free Render — только тест. Для 500–1500 одновременных пользователей бери платный Render/Fly/Railway или VPS.
